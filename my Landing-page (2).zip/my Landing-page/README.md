# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.


project description: 
When clicking an item from the navigation menu, the link should scroll to the appropriate section and highlights it, and when clicking on the top button it scrolls to the top of the page.


1) Used programming languages:
This project was implemented using the programming languages:
HTML
CSS
JavaScript & DOM methods

2) project steps: 
Building the navigation menu:
1-I started by declaring the global variables
2-Initialization function should be used to call all the needed functions which will be executed in the page initialization
3-allSections is an array that holds all the sections tags inside the HTML
navBar will be refering to the navigation bar inside the HTML
sectionsCount is an integer value which will be used later in naming the sections in the navigation bar
4-Initialization function should be used to call all the needed functions which will be executed in the page initialization
5-dynamicNavigationBar function is used for a single section (passed in the parameters) to build a single navigation bar item

The active section:
1-activeClassManipulation() function to dynamically assigining the proper class to the active section and removing it from the others
2-Adding class 'active' to section when near top of viewport using addEventListener




3) Used DOM methods:
ON building the nav:
querySelectorAll
getElementById
forEach
getAttribute
createElement
innerHTML
appendChild

On the active section:
getBoundingClientRect
classList.contains
classList.add
classList.remove
addEventListener



