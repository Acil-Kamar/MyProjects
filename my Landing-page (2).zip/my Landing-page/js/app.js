/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/

//Initializing the variables which will be used later in the functions
//allSections is an array that holds all the sections tags inside the HTML
//navBar will be refering to the navigation bar inside the HTML
//sectionsCount is an integer value which will be used later in naming the sections in the navigation bar

//let allSections = Array.from(document.getElementsByTagName('section'));
let allSections = Array.from(document.querySelectorAll('section'));
let navBar = document.getElementById('navbar__list');
let sectionsCount = 1;


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

//Initialization function should be used to call all the needed functions which will be executed in the page initialization
function initialization()
{
	allSections.forEach(dynamicNavigationBar);
	
}

//dynamicNavigationBar is used for a single section (passed in the parameters) to build a single navigation bar item
function dynamicNavigationBar(item, index)
{
	//Forming the Section Name to be shown in the navbar
	linkText = "Section " + sectionsCount;
	sectionsCount = sectionsCount + 1;
	
	//Acquiring the link value of the current section
	linkValue = item.getAttribute('id');
	
	//Creating the list item to be added to the navigation bar
	listItem = document.createElement('li');
	
	//Forming the HTML hyperlink
	innerHtmlValue = "<a class='menu__link' href='#" + linkValue + "'>" + linkText + "</a>";
	
	//Adding the HTML Hyperlink to the list item
	listItem.innerHTML = innerHtmlValue;
	
	//Adding the list item to the navigation bar
	navBar.appendChild(listItem);
}

//Dynamically assigining the proper class to the active section and removing it from the others
function activeClassManipulation()
{
	//Looping on all sections
	for (section of allSections) 
	{
		//Aquiring the cords of the current sections
		let sectionCords = section.getBoundingClientRect();
		
		//Checking if the current section is after the top boarder of the screen
		if(sectionCords.top >= 0)
		{
			//Checking if the current section also does not have the active class value
			if(!section.classList.contains("your-active-class"))
			{
				//Adding the active class to the current section
				section.classList.add("your-active-class");
			}
		}
		else
		{
			//Removing the active class from the section if it is not after the top boarder
			section.classList.remove('your-active-class');
		}
		
	}
}

// build the nav

//Calling the initialization function
initialization();

// Add class 'active' to section when near top of viewport

document.addEventListener('scroll',activeClassManipulation);

// Scroll to anchor ID using scrollTO event


//scroll to top button:
//Get the button:
mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
 // document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


